import React from "react";

function Article({ counter }, handleDecrement = {}, handleIncrement = {}) {
  return (
    <article className="p-4">
      Hello Visitor,
      <br />
      <br />
      you have <strong> {counter} </strong> unread messages.
      <br />
      <br />
      Please go to your inbox to read them.
    </article>
  );
}

export default Article;
