import React from "react";

function Footer() {
  return (
    <footer className="h-12 border-t border-slate-400 flex items-center px-4 text-sm text-slate-400">
      <br />
      <br />
      <br />
      <br />
      <br />
      by M.A.S.H. DEVeloper (2022)
    </footer>
  );
}

export default Footer;
